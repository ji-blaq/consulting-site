import { Link } from "react-router-dom";

const Hero = () => {
  return (
    <section className="w-full bg-white pt-[80px] pb-[48px] px-[50px] text-center">
      <div className="max-w-[800px] mx-auto">
        <h1 className="text-[48px] leading-[56px] font-semibold text-slate-900">
          Drive Your Business Forward with Expert Consulting
        </h1>

        <p className="mt-[24px] text-[16px] leading-[26px] text-slate-600 max-w-[640px] mx-auto">
          Our expert-driven strategies empower businesses to accelerate growth,
          optimize operations, and overcome challenges, ensuring sustainable
          success in an ever-evolving market.
        </p>

        <div className="mt-[32px] flex items-center justify-center gap-[16px]">
          <Link
            to="/services"
            className="border border-slate-300 rounded-md px-[24px] py-[12px] text-[15px] font-semibold text-slate-800 hover:border-slate-400"
          >
            Discover Our Services
          </Link>
          <Link
            to="/contact"
            className="bg-teal-600 rounded-md px-[24px] py-[12px] text-[15px] font-semibold text-white hover:bg-teal-700"
          >
            Book a Free Consultation
          </Link>
        </div>
      </div>
    </section>
  );
};

export default Hero;