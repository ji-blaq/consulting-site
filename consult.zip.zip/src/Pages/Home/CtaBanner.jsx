import { Link } from "react-router-dom";
import bannerImg from "../../assets/Card1.png";

const CtaBanner = () => {
  return (
    <section className="relative w-full overflow-hidden">
      <img
        src={bannerImg}
        alt=""
        className="absolute inset-0 h-full w-full object-cover"
      />
      {/* Teal wash over the photo — this is the "lowkey" image from Figma */}
      <div className="absolute inset-0 bg-teal-600/80" />

      <div className="relative px-[60px] py-[80px] text-center">
        <h2 className="text-[28px] font-semibold text-white">
          Ready to Transform Your Business?
        </h2>
        <p className="mt-[12px] text-[15px] text-white/90">
          Partner with us for expert guidance and strategies that drive
          growth and success.
        </p>

        <div className="mt-[28px] flex items-center justify-center gap-[16px]">
          <Link
            to="/contact"
            className="rounded-md border border-white/70 px-[24px] py-[12px] text-[15px] font-semibold text-white hover:bg-white/10"
          >
            Contact Us
          </Link>
          <Link
            to="/contact"
            className="rounded-md bg-white px-[24px] py-[12px] text-[15px] font-semibold text-teal-700 hover:bg-slate-100"
          >
            Get Your Free Consultation
          </Link>
        </div>
      </div>
    </section>
  );
};

export default CtaBanner;