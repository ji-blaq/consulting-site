import { Link } from "react-router-dom";
import aboutImg from "../../assets/Card2.png";

const About = () => {
  return (
    <section className="w-full bg-white px-[60px] 
    pb-[40px]">
      <div className="max-w-[1200px] mx-auto grid grid-cols-1 lg:grid-cols-2 gap-[48px] items-center">
        <div>
          <p className="text-[14px] font-medium text-teal-700">About Us</p>

          <h2 className="mt-[12px] text-[32px] leading-[40px] font-semibold text-slate-900">
            Trusted Business Consultants with Proven Results
          </h2>

          <p className="mt-[16px] text-[15px] leading-[26px] text-slate-600">
            With over 20 years of expertise, we empower businesses to achieve
            sustainable growth, optimize operations, and drive profitability
            through strategic consulting tailored to their unique needs. Our
            dedicated team ensures measurable success at every step of your
            journey.
          </p>

          <Link
            to="/about"
            className="mt-[24px] inline-block bg-teal-600 rounded-md px-[24px] py-[12px] text-[15px] font-semibold text-white hover:bg-teal-700"
          >
            Learn More About Us
          </Link>
        </div>

        <img
          src={aboutImg}
          alt="Two consultants reviewing strategy together at a table"
          className="w-full h-[384px] object-cover rounded-xl"
        />
      </div>
    </section>
  );
};

export default About;