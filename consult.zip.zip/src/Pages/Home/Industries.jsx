const industries = [
  {
    title: "Technology",
    text: "Driving innovation and digital transformation to help tech companies scale and thrive in a competitive landscape.",
    linkLabel: "Learn More About Technology Consulting",
  },
  {
    title: "Finance",
    text: "Enhancing profitability and managing financial risks with expert advisory tailored for the financial sector.",
    linkLabel: "Discover Our Finance Expertise",
  },
  {
    title: "Retail",
    text: "Empowering retail businesses to enhance customer experiences and streamline supply chain operations.",
    linkLabel: "See Our Retail Consulting Services",
  },
  {
    title: "Healthcare",
    text: "Improving healthcare efficiency and patient outcomes through process optimization and regulatory expertise.",
    linkLabel: "Explore Healthcare Solutions",
  },
];

const Industries = () => {
  return (
    <section className="w-full bg-slate-50 px-[60px] py-[80px] text-center">
      <p className="text-[14px] font-medium text-teal-700">Industries</p>
      <h2 className="mt-[12px] text-[32px] font-semibold text-slate-900">
        Industries We Serve
      </h2>
      <p className="mt-[16px] max-w-[640px] mx-auto text-[15px] text-slate-600">
        Explore how we help businesses across various industries achieve
        growth, optimize operations, and navigate challenges with our expert
        consulting services.
      </p>

      <div className="mt-[48px] max-w-[900px] mx-auto grid grid-cols-1 sm:grid-cols-2 gap-x-[48px] gap-y-[48px] text-left">
        {industries.map(({ title, text, linkLabel }) => (
          <div key={title}>
            <h3 className="text-[18px] font-semibold text-slate-900">
              {title}
            </h3>
            <p className="mt-[8px] text-[15px] leading-[26px] text-slate-600">
              {text}
            </p>
            <p className="mt-[12px] text-[15px] font-medium text-teal-700 underline">
              {linkLabel}
            </p>
          </div>
        ))}
      </div>
    </section>
  );
};

export default Industries;