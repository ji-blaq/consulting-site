import { Link } from "react-router-dom";
import card1 from "../../assets/Card1.png";
import card2 from "../../assets/Card2.png";
import card3 from "../../assets/Card3.png";

const posts = [
  {
    title: "Navigating Financial Challenges in Uncertain Times",
    text: "Explore how to manage financial risk and optimize cash flow in a volatile economic climate.",
    image: card1,
  },
  {
    title: "Transforming Your Business with Data-Driven Decisions",
    text: "Unlock the potential of data-driven decision-making to enhance your business performance.",
    image: card2,
  },
  {
    title: "How to Improve Client Retention and Build Lasting Relationships",
    text: "Learn the essential strategies for retaining clients and growing your business through strong relationships.",
    image: card3,
  },
];

const Insights = () => {
  return (
    <section className="w-full bg-white px-[60px] py-[80px]">
      <div className="max-w-[1200px] mx-auto flex items-start justify-between gap-[16px]">
        <div>
          <h2 className="text-[32px] font-semibold text-slate-900">
            Expert Insights
          </h2>
          <p className="mt-[8px] max-w-[520px] text-[15px] text-slate-600">
            Stay informed with the latest trends, strategies, and expert
            perspectives in consulting and business growth.
          </p>
        </div>
        <Link
          to="/insights"
          className="whitespace-nowrap border border-slate-300 rounded-md px-[20px] py-[10px] text-[15px] font-semibold text-slate-800 hover:border-slate-400"
        >
          View All
        </Link>
      </div>

      <div className="mt-[40px] max-w-[1200px] mx-auto grid grid-cols-1 sm:grid-cols-3 gap-[32px]">
        {posts.map((post) => (
          <article key={post.title}>
            <img
              src={post.image}
              alt=""
              className="h-[192px] w-full object-cover rounded-xl"
            />
            <h3 className="mt-[16px] text-[16px] font-semibold text-slate-900">
              {post.title}
            </h3>
            <p className="mt-[8px] text-[15px] leading-[26px] text-slate-600">
              {post.text}
            </p>
            <p className="mt-[12px] text-[15px] font-medium text-teal-700 underline">
              Read More
            </p>
          </article>
        ))}
      </div>
    </section>
  );
};

export default Insights;