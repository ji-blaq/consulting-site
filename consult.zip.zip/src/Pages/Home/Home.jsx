import Hero from "./Hero";
import HeroImage from "./HeroImage";
import About from "./About";
import ServiceCards from "./ServiceCards";
import Testimonials from "./Testimonials";
import Industries from "./Industries";
import Insights from "./Insights";
import CaseStudies from "./CaseStudies";

const Home = () => {
  return (
    <>
      <Hero />
      <HeroImage />
      <About />
      <ServiceCards />
      <Testimonials />
      <Industries />
      <Insights />
      <CaseStudies />
    </>
  );
};

export default Home;