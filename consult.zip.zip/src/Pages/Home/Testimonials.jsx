import { useState } from "react";

const testimonials = [
  {
    quote:
      "Their strategic insights helped us streamline our operations and increase profitability by 25% within a year. We couldn't have achieved such success without their expert guidance.",
    name: "Sarah Mitchell",
    role: "CEO, Tech Innovators Inc.",
  },
  {
    quote:
      "The team's risk management framework gave us the confidence to expand into two new markets this year, without losing sight of what makes our business resilient.",
    name: "David Okafor",
    role: "COO, Meridian Retail Group",
  },
  {
    quote:
      "Working with this team felt like adding a dedicated strategy department overnight. Every recommendation was grounded in our actual numbers, not generic playbooks.",
    name: "Priya Raman",
    role: "Founder, Northbridge Health",
  },
];

const Testimonials = () => {
  const [index, setIndex] = useState(0);
  const current = testimonials[index];

  const goPrev = () =>
    setIndex((i) => (i === 0 ? testimonials.length - 1 : i - 1));
  const goNext = () =>
    setIndex((i) => (i === testimonials.length - 1 ? 0 : i + 1));

  return (
    <section className="w-full bg-white px-[60px] py-[80px] text-center">
      <p className="text-[14px] font-medium text-teal-700">Testimonials</p>
      <h2 className="mt-[12px] text-[32px] font-semibold text-slate-900">
        Our Satisfied Clients
      </h2>

      <div className="mt-[40px] flex items-center justify-center gap-[24px]">
        <button
          onClick={goPrev}
          aria-label="Previous testimonial"
          className="h-[40px] w-[40px] rounded-full border border-slate-300 text-slate-600 hover:border-teal-600 hover:text-teal-700"
        >
          ←
        </button>

        <div className="max-w-[640px]">
          <p className="text-[18px] leading-[28px] text-slate-700">
            "{current.quote}"
          </p>
          <p className="mt-[16px] text-[14px] font-medium text-slate-500">
            — {current.name}, {current.role}
          </p>
        </div>

        <button
          onClick={goNext}
          aria-label="Next testimonial"
          className="h-[40px] w-[40px] rounded-full border border-slate-300 text-slate-600 hover:border-teal-600 hover:text-teal-700"
        >
          →
        </button>
      </div>

      <div className="mt-[32px] flex justify-center gap-[8px]">
        {testimonials.map((t, i) => (
          <button
            key={t.name}
            onClick={() => setIndex(i)}
            aria-label={`Go to testimonial ${i + 1}`}
            className={`h-[8px] w-[8px] rounded-full ${
              i === index ? "bg-teal-600" : "bg-slate-200"
            }`}
          />
        ))}
      </div>
    </section>
  );
};

export default Testimonials;