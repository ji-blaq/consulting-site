import { Link } from "react-router-dom";

const Icon = ({ path }) => (
  <svg
    className="h-[24px] w-[24px]"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="1.5"
  >
    <path d={path} />
  </svg>
);

const services = [
  {
    title: "Business Strategy Consulting",
    text: "Customized strategic plans that help your business achieve long-term goals and stay ahead of the competition.",
    icon: "M4 19V5a2 2 0 0 1 2-2h8l6 6v10a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2ZM14 3v6h6M9 14h6M9 10h2",
  },
  {
    title: "Risk Management Consulting",
    text: "Identify, plan for, and reduce the operational and financial risks that can slow your business down.",
    icon: "M12 3 4 7v5c0 5 3.4 8.7 8 9 4.6-.3 8-4 8-9V7l-8-4Z",
  },
  {
    title: "Operational Efficiency",
    text: "Streamlined processes and sharper performance metrics so your team does more with what it already has.",
    icon: "M12 2v4M12 18v4M4.9 4.9l2.8 2.8M16.3 16.3l2.8 2.8M2 12h4M18 12h4M4.9 19.1l2.8-2.8M16.3 7.7l2.8-2.8",
  },
];

const ServiceCards = () => {
  return (
    <section className="w-full bg-white px-[60px] py-[80px]">
      <div className="max-w-[1200px] mx-auto flex items-start justify-between gap-[16px]">
        <div>
          <p className="text-[14px] font-medium text-teal-700">What We Do</p>
          <h2 className="mt-[12px] text-[32px] font-semibold text-slate-900">
            Solutions Built Around Your Business
          </h2>
        </div>
        <Link
          to="/services"
          className="whitespace-nowrap border border-slate-300 rounded-md px-[20px] py-[10px] text-[15px] font-semibold text-slate-800 hover:border-slate-400"
        >
          View All Services
        </Link>
      </div>

      <div className="mt-[40px] max-w-[1200px] mx-auto grid grid-cols-1 md:grid-cols-3 gap-[24px]">
        {services.map((service) => (
          <div
            key={service.title}
            className="group rounded-xl border border-slate-200 p-[32px] transition hover:-translate-y-[4px] hover:shadow-lg hover:border-teal-600"
          >
            <div className="flex h-[48px] w-[48px] items-center justify-center rounded-full bg-teal-50 text-teal-600 group-hover:bg-teal-600 group-hover:text-white transition">
              <Icon path={service.icon} />
            </div>

            <h3 className="mt-[20px] text-[18px] font-semibold text-slate-900">
              {service.title}
            </h3>

            <p className="mt-[8px] text-[14px] leading-[24px] text-slate-600">
              {service.text}
            </p>

            <Link
              to="/services"
              className="mt-[20px] inline-flex items-center gap-[6px] text-[14px] font-medium text-teal-700"
            >
              Learn More
              <span className="transition group-hover:translate-x-[3px]">→</span>
            </Link>
          </div>
        ))}
      </div>
    </section>
  );
};

export default ServiceCards;