import { useState } from "react";
import { NavLink, Link } from "react-router-dom";
import Logo from "../assets/logo.png"; // Adjust the path to your logo image

const navItems = [
  { label: "Home", to: "/", end: true },
  { label: "Services", to: "/services" },
  { label: "Industries", to: "/industries" },
  { label: "Case Studies", to: "/case-studies" },
  { label: "Insights", to: "/insights" },
  { label: "About Us", to: "/about" },
  { label: "Contact Us", to: "/contact" },
];

const navLinkClass = ({ isActive }) =>
  `text-[15px] font-medium transition ${
    isActive
      ? "text-teal-700 font-semibold"
      : "text-slate-700 hover:text-teal-700"
  }`;

const Navbar = () => {
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <header className="w-full h-[90px] bg-white border-b border-slate-100 flex items-center px-[60px] justify-between">
      <Link to="/" className="text-xl font-semibold text-slate-900">
        <img src={Logo} alt="Company Logo" className="h-20" />
      </Link>

      <div className="hidden lg:flex items-center gap-8">
        {navItems.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            end={item.end}
            className={navLinkClass}
          >
            {item.label}
          </NavLink>
        ))}
      </div>

      <Link
        to="/contact"
        className="hidden lg:block bg-teal-600 text-white text-[15px] font-semibold rounded-md px-6 py-3 hover:bg-teal-700"
      >
        Free Consultation
      </Link>

      <button className="lg:hidden text-slate-700" onClick={() => setMobileOpen((v) => !v)}>
        ☰
      </button>

      {mobileOpen && (
        <div className="absolute top-[90px] left-0 w-full bg-white border-t border-slate-100 flex flex-col px-[60px] py-4 lg:hidden">
          {navItems.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.end}
              className={({ isActive }) =>
                `py-2 text-[15px] ${
                  isActive ? "text-teal-700 font-semibold" : "text-slate-700"
                }`
              }
            >
              {item.label}
            </NavLink>
          ))}
        </div>
      )}
    </header>
  );
};

export default Navbar;